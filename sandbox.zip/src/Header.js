import React from "react";
import { Link } from "react-router-dom";
import styles from "./styles.module.css";

function Header() {
  return (
    <div className={styles.container}>
      <h1 className={styles.title}>My App</h1>
      <nav>
        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/about">About</Link>
          </li>
        </ul>
      </nav>
    </div>
  );
}

export default Header;
