import React from "react";
import styles from "./styles.module.css";

function Footer() {
  return (
    <div className={styles.container}>
      <p className={styles.paragraph}>© 2022 My App. All rights reserved.</p>
    </div>
  );
}

export default Footer;
